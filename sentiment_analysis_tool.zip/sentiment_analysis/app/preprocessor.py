

import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib
import os


for corpus in ("stopwords", "wordnet", "punkt", "punkt_tab", "omw-1.4"):
    nltk.download(corpus, quiet=True)

STOP_WORDS = set(stopwords.words("english"))

KEEP_WORDS = {"not", "no", "never", "nor", "neither", "hardly", "barely", "scarcely"}
STOP_WORDS -= KEEP_WORDS

lemmatizer = WordNetLemmatizer()


def clean_text(text: str) -> str:
    """Remove noise: URLs, HTML tags, special characters, digits."""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", "", text)          # URLs
    text = re.sub(r"<.*?>", "", text)                    # HTML tags
    text = re.sub(r"[^a-z\s]", " ", text)               # non-alpha chars
    text = re.sub(r"\s+", " ", text).strip()             # extra whitespace
    return text


def tokenise(text: str) -> list[str]:
    """Tokenise cleaned text into words."""
    return word_tokenize(text)


def remove_stopwords(tokens: list[str]) -> list[str]:
    """Drop stop words while preserving negation tokens."""
    return [t for t in tokens if t not in STOP_WORDS and len(t) > 1]


def lemmatise(tokens: list[str]) -> list[str]:
    """Reduce tokens to base/root form."""
    return [lemmatizer.lemmatize(t) for t in tokens]


def preprocess(text: str) -> str:
    """
    Full pipeline: clean → tokenise → remove stop-words → lemmatise → join.
    Returns a single processed string ready for TF-IDF.
    """
    text = clean_text(text)
    tokens = tokenise(text)
    tokens = remove_stopwords(tokens)
    tokens = lemmatise(tokens)
    return " ".join(tokens)


class SentimentVectorizer:
    """Wrapper around TfidfVectorizer with save/load support."""

    def __init__(self, max_features: int = 10_000, ngram_range: tuple = (1, 2)):
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            sublinear_tf=True,    # apply log(1 + tf) scaling
        )

    def fit_transform(self, texts):
        processed = [preprocess(t) for t in texts]
        return self.vectorizer.fit_transform(processed)

    def transform(self, texts):
        processed = [preprocess(t) for t in texts]
        return self.vectorizer.transform(processed)

    def save(self, path: str):
        joblib.dump(self.vectorizer, path)
        print(f"Vectorizer saved → {path}")

    def load(self, path: str):
        self.vectorizer = joblib.load(path)
        return self


if __name__ == "__main__":
    sample = "This product is absolutely amazing!! Check http://example.com for details."
    print("Raw     :", sample)
    print("Cleaned :", clean_text(sample))
    print("Processed:", preprocess(sample))
