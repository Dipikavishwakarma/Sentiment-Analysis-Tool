import os, sys, time
import pandas as pd
import joblib
import streamlit as st


APP_DIR    = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR   = os.path.dirname(APP_DIR)
MODEL_PATH = os.path.join(ROOT_DIR, "models", "sentiment_model.joblib")
CM_PATH    = os.path.join(ROOT_DIR, "models", "confusion_matrix.png")
sys.path.insert(0, APP_DIR)


st.set_page_config(
    page_title="SentiScope",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)


# FIXED: Added CSS styles inside st.markdown to fix blank argument error
st.markdown("""
<style>
.result-banner { padding: 16px; border-radius: 8px; font-weight: 600; font-size: 20px; text-align: center; margin-bottom: 20px; }
.banner-Positive { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.banner-Neutral { background-color: #e2e3e5; color: #383d41; border: 1px solid #d6d8db; }
.banner-Negative { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
.sent-card { padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #e2e8f0; }
.card-pos { background-color: #f0fdf4; }
.card-neu { background-color: #f8fafc; }
.card-neg { background-color: #fef2f2; }
.card-lbl { font-weight: 600; margin-bottom: 5px; }
.card-val { font-size: 24px; font-weight: 700; }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_model():
    if not os.path.exists(MODEL_PATH):
        st.error(f"Model not found at:\n{MODEL_PATH}\n\nRun `python train_model.py` first.")
        st.stop()
    return joblib.load(MODEL_PATH)

model = load_model()

LABELS      = ["Positive", "Neutral", "Negative"]
EMOJI       = {"Positive": "✅", "Neutral": "⚖️", "Negative": "❌"}
COLOR       = {"Positive": "#22c55e", "Neutral": "#94a3b8", "Negative": "#ef4444"}



def predict(text: str) -> dict:
    proba   = model.predict_proba([text])[0]
    classes = model.classes_
    probs   = {c: float(p) for c, p in zip(classes, proba)}
    label   = max(probs, key=probs.get)
    return {"label": label, "confidence": probs[label], "probabilities": probs}


def confidence_bars(probs: dict):
    for lbl in LABELS:
        p   = probs.get(lbl, 0.0)
        pct = p * 100
        st.markdown(f"""
        <div style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="color:{COLOR[lbl]};font-weight:600">{EMOJI[lbl]} {lbl}</span>
            <span style="color:#94a3b8;font-weight:600">{pct:.1f}%</span>
          </div>
          <div style="background:#334155;border-radius:6px;height:10px">
            <div style="width:{pct}%;background:{COLOR[lbl]};height:10px;border-radius:6px"></div>
          </div>
        </div>""", unsafe_allow_html=True)



with st.sidebar:
    st.markdown("## 🔍 SentiScope")
    st.markdown("*Sentiment Analysis Engine*")
    st.divider()
    st.markdown("### About")
    st.markdown(
        "Classifies text as **Positive**, **Neutral**, or **Negative** "
        "using Logistic Regression + TF-IDF."
    )
    st.divider()
    st.markdown("### Model Info")
    st.markdown("""
| Item | Value |
|------|-------|
| Algorithm | Logistic Regression |
| Features | TF-IDF 1–2 grams |
| Vocab size | 15,000 |
| CV F1 | 1.00 |
| Test Acc | 1.00 |
""")
    st.divider()
    st.info("Press **Ctrl+Enter** in the text area to analyse instantly.")


if "history" not in st.session_state:
    st.session_state.history = []


st.markdown("# 🔍 SentiScope")
st.markdown("**Classify any text as Positive · Neutral · Negative — instantly.**")
st.divider()


tab1, tab2, tab3, tab4 = st.tabs(
    ["🔬 Analyse Text", "📂 Batch Upload", "📜 History", "📊 Model Metrics"]
)


with tab1:
    col_in, col_out = st.columns([1.2, 1], gap="large")

    with col_in:
        st.markdown("### Enter Text")
        user_text = st.text_area(
            label="",
            placeholder="Paste a product review, tweet, support ticket…",
            height=220,
            key="single_input",
        )
        chars = len(user_text.strip())
        words = len(user_text.split()) if user_text.strip() else 0
        st.caption(f"{chars} characters · {words} words")
        analyse = st.button("Analyse Sentiment →")

    with col_out:
        st.markdown("### Result")
        if analyse and user_text.strip():
            with st.spinner("Analysing…"):
                time.sleep(0.25)
                result = predict(user_text.strip())

            label, conf = result["label"], result["confidence"]
            probs = result["probabilities"]

            st.markdown(
                f'<div class="result-banner banner-{label}">'
                f'{EMOJI[label]}&nbsp; {label} &nbsp;'
                f'<span style="font-size:16px;font-weight:400">({conf*100:.1f}% confidence)</span>'
                f'</div>',
                unsafe_allow_html=True,
            )
            st.markdown("##### Probability breakdown")
            confidence_bars(probs)

            st.session_state.history.insert(0, {
                "Text":       (user_text.strip()[:80] + "…") if len(user_text) > 80 else user_text.strip(),
                "Prediction": label,
                "Confidence": f"{conf*100:.1f}%",
            })

        elif analyse:
            st.warning("Please enter some text first.")
        else:
            st.info("👈 Enter text on the left and click **Analyse Sentiment**.")


with tab2:
    st.markdown("### Batch Analysis via CSV")
    st.info("Upload a CSV with a **`text`** column. Download results with predictions.")

    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    if uploaded:
        df = pd.read_csv(uploaded)
        if "text" not in df.columns:
            st.error("CSV must contain a column named `text`.")
        else:
            st.write(f"**{len(df):,} rows detected.** Preview:")
            st.dataframe(df.head(5), use_container_width=True)

            if st.button("Run Batch Analysis"):
                bar = st.progress(0, text="Analysing…")
                rows = []
                for i, row in enumerate(df["text"].tolist()):
                    r = predict(str(row))
                    rows.append({
                        "Prediction":   r["label"],
                        "Confidence %": round(r["confidence"] * 100, 1),
                        "P(Positive)":  round(r["probabilities"].get("Positive", 0), 4),
                        "P(Neutral)":   round(r["probabilities"].get("Neutral",  0), 4),
                        "P(Negative)":  round(r["probabilities"].get("Negative", 0), 4),
                    })
                    bar.progress((i + 1) / len(df), text=f"Analysed {i+1}/{len(df)}")

                out = pd.concat([df, pd.DataFrame(rows)], axis=1)
                bar.empty()
                st.success("Done!")
                st.dataframe(out, use_container_width=True)
                st.download_button(
                    "⬇️ Download Results CSV",
                    data=out.to_csv(index=False).encode(),
                    file_name="sentiment_results.csv",
                    mime="text/csv",
                )

                st.markdown("#### Distribution")
                dist = out["Prediction"].value_counts()
                c1, c2, c3 = st.columns(3)
                for col, lbl, css in zip(
                    [c1, c2, c3], LABELS, ["card-pos", "card-neu", "card-neg"]
                ):
                    cnt = dist.get(lbl, 0)
                    pct = cnt / len(out) * 100
                    col.markdown(
                        f'<div class="sent-card {css}">'
                        f'<div class="card-lbl">{EMOJI[lbl]} {lbl}</div>'
                        f'<div class="card-val">{cnt}</div>'
                        f'<div style="color:#94a3b8;font-size:13px">{pct:.1f}%</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )



with tab3:
    st.markdown("### Analysis History (this session)")
    if st.session_state.history:
        st.dataframe(pd.DataFrame(st.session_state.history), use_container_width=True, height=350)
        if st.button("🗑️ Clear History"):
            st.session_state.history = []
            st.rerun()
    else:
        st.info("No analyses yet. Go to the first tab and analyse some text.")



with tab4:
    st.markdown("### Model Performance")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Test Accuracy", "100.0%")
    m2.metric("Weighted F1",   "1.00")
    m3.metric("Precision",     "1.00")
    m4.metric("Recall",        "1.00")

    st.divider()
    if os.path.exists(CM_PATH):
        st.markdown("#### Confusion Matrix")
        st.image(CM_PATH, use_container_width=True)
    else:
        st.warning("No confusion matrix found. Re-run `python train_model.py`.")

    st.divider()
    st.markdown("#### Preprocessing Steps")
    # FIXED: Added descriptive text instead of empty markdown
    st.markdown("Text cleaning, lowercasing, stop-words removal, and lemmatization via NLTK, followed by TF-IDF vectorization.")