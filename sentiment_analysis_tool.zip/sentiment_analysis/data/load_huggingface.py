"""
load_huggingface.py
-------------------
Downloads the TweetEval sentiment dataset from Hugging Face and saves it
in the format expected by train_model.py.

Install:  pip install datasets
Run:      python data/load_huggingface.py
Then:     python train_model.py
"""

import os
import pandas as pd

OUT = os.path.join(os.path.dirname(__file__), "sentiment_data.csv")

LABEL_MAP = {0: "Negative", 1: "Neutral", 2: "Positive"}


def main():
    try:
        from datasets import load_dataset
    except ImportError:
        print("Install the datasets library first:  pip install datasets")
        return

    print("Downloading TweetEval sentiment dataset …")
    ds = load_dataset("tweet_eval", "sentiment", split="train")

    df = pd.DataFrame({
        "text":  ds["text"],
        "label": [LABEL_MAP[l] for l in ds["label"]],
    })

    print("Distribution:")
    print(df["label"].value_counts().to_string(), "\n")

    df.to_csv(OUT, index=False)
    print(f"Saved {len(df):,} rows → {OUT}")
    print("\nNow run:  python train_model.py")


if __name__ == "__main__":
    main()
