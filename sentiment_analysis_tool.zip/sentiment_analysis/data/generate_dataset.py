"""
generate_dataset.py
-------------------
Generates a balanced synthetic sentiment dataset with 3,000 samples.
Replace this with real data (Kaggle / Twitter) for production use.
Output: data/sentiment_data.csv  (columns: text, label)
"""

import os, random
import pandas as pd

random.seed(42)

POSITIVE = [
    "This product is absolutely amazing, totally worth every penny!",
    "I love how easy and intuitive this app is to use.",
    "Exceptional quality and the customer support was fantastic.",
    "Best purchase I've made this year — highly recommend it!",
    "The delivery was super fast and the packaging was perfect.",
    "Outstanding performance, exceeded all my expectations.",
    "Really impressed with the build quality and features.",
    "Five stars! Will definitely buy again from this store.",
    "Great value for money, works exactly as described.",
    "Incredible experience from start to finish, very satisfied.",
    "The team went above and beyond to help me out.",
    "Setup was a breeze, up and running in minutes.",
    "Smooth, reliable, and exactly what I needed.",
    "Loving the results — already recommended to three friends.",
    "Super happy with my purchase, zero complaints.",
    "This exceeded my expectations in every single way.",
    "Brilliant product, I use it every single day now.",
    "Very pleased with the quality and lightning-fast shipping.",
    "Game changer for my workflow, incredibly useful.",
    "Delighted with this buy — packaging was also eco-friendly.",
]

NEGATIVE = [
    "Terrible experience, the product stopped working after two days.",
    "Extremely disappointed — nothing like what was advertised.",
    "Worst customer service I have ever encountered, absolutely horrible.",
    "Complete waste of money, broke almost immediately.",
    "Do NOT buy this — it is a total scam.",
    "Very poor quality, looks nothing like the pictures.",
    "Returned it within a week, utterly useless product.",
    "The app crashes constantly and support never responds.",
    "Awful experience, shipping took three weeks and arrived damaged.",
    "I regret this purchase so much, zero stars if I could.",
    "Defective right out of the box, very frustrating.",
    "Instructions were useless and the product just does not work.",
    "Terrible build quality, feels cheap and flimsy.",
    "Huge disappointment, expected much better for the price.",
    "Never buying from this brand again after this disaster.",
    "Customer support was rude and completely unhelpful.",
    "Stopped working after the first use — total junk.",
    "Misleading description, product is nothing like what was shown.",
    "Waste of time and money, avoid at all costs.",
    "Deeply unhappy with this, seeking a refund immediately.",
]

NEUTRAL = [
    "The product is okay, does what it is supposed to do.",
    "Average quality for the price, nothing special.",
    "It arrived on time and works as described.",
    "Neither great nor terrible, just a basic product.",
    "Decent enough for occasional use, nothing remarkable.",
    "The item is fine, met basic expectations.",
    "It does the job but there is room for improvement.",
    "Pretty standard product, not much to say about it.",
    "Works as expected, no surprises either way.",
    "Reasonable purchase, although not particularly impressive.",
    "Product is acceptable, delivery was on schedule.",
    "It is alright, I have seen both better and worse.",
    "Nothing exceptional, but nothing terrible either.",
    "Functional and straightforward, does what it claims.",
    "Mid-range quality consistent with the price point.",
    "Average experience overall, would probably not repurchase.",
    "The product is serviceable but not outstanding.",
    "It does what it says on the box, no more no less.",
    "Okay for casual use, professionals may want more.",
    "Fair product for the cost, standard quality.",
]

FILLERS = {
    "Positive": ["Really.", "10/10.", "Absolutely.", "Period.", "For sure."],
    "Negative": ["Disgusting.", "Never again.", "0/10.", "Terrible.", "Appalling."],
    "Neutral":  [],
}


def generate(n_per_class: int = 1000) -> pd.DataFrame:
    records = []
    for label, templates in [("Positive", POSITIVE), ("Negative", NEGATIVE), ("Neutral", NEUTRAL)]:
        pool = templates * (n_per_class // len(templates) + 2)
        for i in range(n_per_class):
            text = pool[i]
            if FILLERS[label] and random.random() > 0.4:
                text = text + " " + random.choice(FILLERS[label])
            records.append({"text": text, "label": label})

    df = pd.DataFrame(records).sample(frac=1, random_state=42).reset_index(drop=True)
    return df


if __name__ == "__main__":
    out_path = os.path.join(os.path.dirname(__file__), "sentiment_data.csv")
    df = generate()
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df):,} rows → {out_path}")
    print(df["label"].value_counts().to_string())
