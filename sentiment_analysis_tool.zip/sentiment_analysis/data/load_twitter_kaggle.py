"""
load_twitter_kaggle.py
----------------------
Converts the Sentiment140 Kaggle dataset to the format expected by train_model.py.

Steps:
  1. Download from https://www.kaggle.com/datasets/kazanova/sentiment140
  2. Place the CSV in this folder (data/)
  3. Run:  python data/load_twitter_kaggle.py
  4. Then: python train_model.py
"""

import os
import pandas as pd

RAW   = os.path.join(os.path.dirname(__file__), "training.1600000.processed.noemoticon.csv")
OUT   = os.path.join(os.path.dirname(__file__), "sentiment_data.csv")

LABEL_MAP = {0: "Negative", 2: "Neutral", 4: "Positive"}
N_PER_CLASS = 10_000   # increase for more data; 10k per class trains in ~30s


def main():
    print(f"Loading {RAW} …")
    df = pd.read_csv(
        RAW,
        encoding="latin-1",
        header=None,
        names=["polarity", "id", "date", "query", "user", "text"],
    )
    df["label"] = df["polarity"].map(LABEL_MAP)
    df = df.dropna(subset=["label", "text"])

    print("Original distribution:")
    print(df["label"].value_counts().to_string(), "\n")

    # Balanced sample
    sampled = (
        df.groupby("label")
        .apply(lambda g: g.sample(min(N_PER_CLASS, len(g)), random_state=42))
        .reset_index(drop=True)
    )

    out = sampled[["text", "label"]].sample(frac=1, random_state=42).reset_index(drop=True)
    out.to_csv(OUT, index=False)
    print(f"Saved {len(out):,} rows → {OUT}")
    print(out["label"].value_counts().to_string())
    print("\nNow run:  python train_model.py")


if __name__ == "__main__":
    main()
