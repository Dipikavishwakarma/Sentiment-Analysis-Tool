# 🔍 SentiScope — Sentiment Analysis Tool

A full-stack NLP project that classifies text feedback as **Positive**, **Neutral**, or **Negative** using classical ML (Logistic Regression + TF-IDF) with a professional Streamlit web UI.

---

## 📁 Project Structure

```
sentiment_analysis/
├── data/
│   ├── generate_dataset.py     # Synthetic dataset generator (swap with real data)
│   └── sentiment_data.csv      # 3,000 labelled samples (auto-generated)
├── app/
│   ├── preprocessor.py         # Full NLTK preprocessing pipeline
│   └── app.py                  # Streamlit web application
├── models/
│   ├── sentiment_model.joblib  # Trained model + vectorizer (sklearn Pipeline)
│   └── confusion_matrix.png    # Evaluation artefact
├── train_model.py              # Training script with GridSearchCV
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Generate dataset (or use your own CSV with `text` + `label` columns)
```bash
python data/generate_dataset.py
```

### 3. Train the model
```bash
python train_model.py
```

### 4. Launch the app
```bash
streamlit run app/app.py
```

---

## 📊 Dataset

| Source | Notes |
|--------|-------|
| Synthetic (default) | 3,000 samples, 1,000 per class |
| Twitter/X API | Public tweets filtered by hashtags |
| Amazon/Yelp reviews | Available on Kaggle |
| Internal feedback | Custom CSV with `text` + `label` columns |

To use a real dataset, save it as `data/sentiment_data.csv` with columns `text` and `label` (values: `Positive`, `Neutral`, `Negative`).

---

## 🔧 Preprocessing Pipeline

```
Raw text
  → Lowercase + strip URLs/HTML/special chars
  → Tokenise (NLTK word_tokenize)
  → Remove stop words (keep negations: not, never, no…)
  → Lemmatise (WordNetLemmatizer)
  → TF-IDF vectorise (15k features, unigrams + bigrams)
```

---

## 🤖 Model

- **Algorithm:** Logistic Regression (`class_weight="balanced"` for imbalanced data)
- **Features:** TF-IDF with `sublinear_tf=True` and 1–2 gram range
- **Tuning:** 5-fold `GridSearchCV` over regularisation strength `C`
- **Wrapper:** sklearn `Pipeline` to prevent data leakage during CV

---

## 📈 Results

| Metric | Score |
|--------|-------|
| Test Accuracy | 1.00 |
| Weighted F1 | 1.00 |
| Cross-val F1 | 1.00 |

> **Note:** Perfect scores reflect the synthetic dataset's low lexical diversity. Real-world datasets will show more realistic metrics (typically 85–92% accuracy with this approach).

---

## 🖥️ App Features

| Feature | Detail |
|---------|--------|
| Single text analysis | Paste any text, get instant prediction + confidence |
| Confidence breakdown | Per-class probability bars |
| Batch CSV upload | Upload thousands of rows, download results |
| Analysis history | Session-level prediction log |
| Model metrics | Confusion matrix + evaluation table |

---

## 🔮 Upgrade Path (Advanced)

To push accuracy higher on real-world data, replace the Logistic Regression with:

```python
from transformers import pipeline
classifier = pipeline("text-classification", model="distilbert-base-uncased-finetuned-sst-2-english")
```

Or fine-tune DistilBERT on your custom dataset using Hugging Face `Trainer`.

---

## 🧠 Key Learnings

- Full ML pipeline: data → preprocess → train → evaluate → deploy
- Importance of retaining negation words in stop-word removal
- Sklearn `Pipeline` as a best practice to prevent CV data leakage
- `class_weight="balanced"` for robust performance on imbalanced datasets
- Streamlit for rapid, professional ML app deployment
