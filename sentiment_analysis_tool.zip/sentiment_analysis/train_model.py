"""
train_model.py
--------------
Trains a Logistic Regression classifier on the sentiment dataset.
Saves: trained model and evaluation artefacts (confusion_matrix.png).

Senior-level practices:
  - Stratified train/test split
  - sklearn Pipeline (prevents data leakage in CV)
  - GridSearchCV for C hyperparameter tuning
  - Full classification report + confusion matrix visualisation
"""

import os, sys
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer

# ── resolve paths relative to this file so it works anywhere ─────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATA_PATH   = os.path.join(BASE_DIR, "data", "sentiment_data.csv")
MODEL_DIR   = os.path.join(BASE_DIR, "models")
MODEL_PATH  = os.path.join(MODEL_DIR, "sentiment_model.joblib")
REPORT_PATH = os.path.join(MODEL_DIR, "confusion_matrix.png")
os.makedirs(MODEL_DIR, exist_ok=True)

sys.path.insert(0, os.path.join(BASE_DIR, "app"))
from preprocessor import preprocess

LABEL_ORDER = ["Positive", "Neutral", "Negative"]


# ─────────────────────────────────────────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    assert {"text", "label"}.issubset(df.columns), \
        "CSV must have 'text' and 'label' columns."
    df = df.dropna(subset=["text", "label"])
    print(f"Loaded {len(df):,} samples")
    print(df["label"].value_counts().to_string(), "\n")
    return df


def build_pipeline() -> Pipeline:
    """
    Wrapping TF-IDF + classifier in a Pipeline ensures the vectorizer
    is only fitted on training data — critical for valid cross-validation.
    """
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            preprocessor=preprocess,   # custom NLTK pipeline
            max_features=15_000,
            ngram_range=(1, 2),        # unigrams + bigrams
            sublinear_tf=True,         # log(1+tf) dampens high-freq terms
        )),
        ("clf", LogisticRegression(
            max_iter=1000,
            class_weight="balanced",   # handles imbalanced datasets
            random_state=42,
            solver="lbfgs",
        )),
    ])


def tune_and_train(pipeline: Pipeline, X_train: list, y_train: list) -> Pipeline:
    """GridSearchCV over regularisation strength C (5-fold stratified CV)."""
    param_grid = {"clf__C": [0.01, 0.1, 0.5, 1.0, 5.0, 10.0]}
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    print("Running GridSearchCV …")
    gs = GridSearchCV(
        pipeline, param_grid, cv=cv,
        scoring="f1_weighted", n_jobs=-1, verbose=1,
    )
    gs.fit(X_train, y_train)
    print(f"\nBest C = {gs.best_params_['clf__C']}  |  CV F1 = {gs.best_score_:.4f}\n")
    return gs.best_estimator_


def evaluate(model: Pipeline, X_test: list, y_test: list):
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    f1  = f1_score(y_test, y_pred, average="weighted")

    print("=" * 55)
    print(f"  Test Accuracy  : {acc:.4f}")
    print(f"  Weighted F1    : {f1:.4f}")
    print("=" * 55)
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=LABEL_ORDER))

    _plot_confusion_matrix(y_test, y_pred)
    return acc, f1


def _plot_confusion_matrix(y_true, y_pred):
    cm      = confusion_matrix(y_true, y_pred, labels=LABEL_ORDER)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.patch.set_facecolor("#0f172a")

    for ax, data, title, fmt in zip(
        axes,
        [cm, cm_norm],
        ["Confusion Matrix (counts)", "Confusion Matrix (normalised)"],
        ["d", ".2f"],
    ):
        sns.heatmap(data, annot=True, fmt=fmt, cmap="Blues",
                    xticklabels=LABEL_ORDER, yticklabels=LABEL_ORDER,
                    ax=ax, linewidths=0.5, cbar_kws={"shrink": 0.8})
        ax.set_title(title, color="white", fontsize=13, pad=12)
        ax.set_xlabel("Predicted", color="#94a3b8")
        ax.set_ylabel("Actual",    color="#94a3b8")
        ax.tick_params(colors="white")
        ax.set_facecolor("#1e293b")
        for spine in ax.spines.values():
            spine.set_edgecolor("#334155")

    plt.tight_layout(pad=2)
    plt.savefig(REPORT_PATH, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"Confusion matrix → {REPORT_PATH}")


# ─────────────────────────────────────────────────────────────────────────────
def main():
    df = load_data(DATA_PATH)
    X, y = df["text"].tolist(), df["label"].tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    print(f"Train: {len(X_train):,}  |  Test: {len(X_test):,}\n")

    pipeline  = build_pipeline()
    best_model = tune_and_train(pipeline, X_train, y_train)
    acc, f1   = evaluate(best_model, X_test, y_test)

    joblib.dump(best_model, MODEL_PATH)
    print(f"\nModel saved → {MODEL_PATH}")
    print(f"Done!  Accuracy={acc:.4f}  F1={f1:.4f}")


if __name__ == "__main__":
    main()
