# Sentiment Analysis Tool

## Run Locally

1. Install dependencies

pip install -r requirements.txt

2. Start the application

streamlit run app.py

## Features
- Positive / Neutral / Negative sentiment detection
- Simple Streamlit UI
- Uses TextBlob sentiment analysis
