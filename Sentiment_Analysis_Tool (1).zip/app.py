
import streamlit as st
from textblob import TextBlob

st.set_page_config(page_title="Sentiment Analysis Tool", page_icon="😊")

st.title("Sentiment Analysis Tool")
st.write("Enter text and detect whether the sentiment is Positive, Neutral, or Negative.")

text = st.text_area("Enter text:")

if st.button("Analyze Sentiment"):
    if text.strip():
        polarity = TextBlob(text).sentiment.polarity

        if polarity > 0.1:
            sentiment = "Positive 😊"
        elif polarity < -0.1:
            sentiment = "Negative 😞"
        else:
            sentiment = "Neutral 😐"

        st.subheader("Result")
        st.success(sentiment)

        confidence = min(abs(polarity) * 100, 100)
        st.write(f"Polarity Score: {polarity:.2f}")
        st.progress(int(confidence))
    else:
        st.warning("Please enter some text.")
